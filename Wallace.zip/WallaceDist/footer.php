		<div hidden>
		    <?php echo file_get_contents( get_template_directory_uri() . '/assets/icons.svg' ); ?>
		</div>
		<?php wp_footer(); ?>
	
	
	</body>
</html>