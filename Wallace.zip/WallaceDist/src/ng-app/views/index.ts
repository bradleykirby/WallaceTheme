export { HomeViewComponent } from './home.view';
export { PostViewComponent } from './post.view';
