module.exports = {
  plugins: [
    require('postcss-object-fit-images'),
    require('autoprefixer')
  ]
}