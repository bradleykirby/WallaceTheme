<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">    
        <base href="/"/>
        <link href="https://fonts.googleapis.com/css?family=Fjord+One|Montserrat|Open+Sans:300" rel="stylesheet">
        <?php wp_head(); ?>
        

