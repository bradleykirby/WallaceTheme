``from``
========

The ``from`` tag imports :doc:`macro<../tags/macro>` names into the current
namespace. The tag is documented in detail in the documentation for the
:doc:`import<../tags/import>` tag.

.. seealso:: :doc:`macro<../tags/macro>`, :doc:`import<../tags/import>`
